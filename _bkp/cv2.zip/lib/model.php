<?php

namespace CV\lib;
use \CV\lib\Data_Object as Obj;

class Model implements \CV\Config
{
	const T_VARCHAR = 'varchar';
	const T_INT = 'int';
	const T_FLOAT = 'float';
	const T_TEXT = 'text';
	
	private static $db;
	protected $table;
	protected $primary;
	
	function __construct()
	{
		if ( !self::$db )
			self::$db = new \CV\DB( self::DB_HOST, self::DB_USER, self::DB_PASW, self::DB_NAME );
		$this->table = strtolower( basename( get_called_class() ) );
	}
	
	public function &db()
	{
		return self::$db;
	}
	
	public function primary()
	{
		return $this->primary;
	}
	
	public function table()
	{
		return $this->table;
	}
	
	protected function select( $additional )
	{
		//var_dump(basename(get_called_class()));
		return self::$db->fetch( "SELECT * FROM $this->table ". $additional );
	}
	
	protected function update()
	{
		//self::$db->query( 'UPDATE s')
		return new ModelUpdate($this);
	}	
}

class ModelAttributes
{
	
}

class ModelUpdate
{
	protected $db;
	protected $stack;
	protected $model;
	
	function __construct( \CV\lib\Model $model )
	{
		$this->stack = new Obj;
		$this->db =& $model->db();
		$this->model =& $model;
		//$this->db->start();
	}
	
	public function __set( $key, $value )
	{
		if ( !isset( $this->stack->$key ) )
			$this->stack->$key = array();
		$this->stack->{$key}[] = $value;
	}
	
	public function save()
	{
		//var_dump($this->stack);
		try {
			$rows = $this->stack->{ $this->model->primary() };
			for ( $i = 0; $i < sizeof( $rows ); $i++ ) {
				$row = '';
				$where = '';
				$j = 0;
				foreach ( $this->stack as $column=>$values ) {
					if ( $column == $this->model->primary() )
						$where = "$column = '{$values[$i]}'";
					else {
						$row .= "$column = '{$values[$i]}'";
						if ( $j < sizeof( $rows )-2 )
							$row .= ', ';
					}
					$j++;
				}
				$query = "UPDATE {$this->model->table()} SET ". $row. ' WHERE '. $where;
				print $query. "\n";

				$this->db->query( $query );
			}
		} catch ( \Exception $e ) {
			//$this->db->rollback();
			print $this->db->getDb()->error;
			exit;
		}
		//$this->db->commit();
	}
}

?>
