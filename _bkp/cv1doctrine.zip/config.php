<?php

namespace CV;

interface DB_Config
{
	const HOST = 'localhost';
	const USER = 'root';
	const PASW = '';
	const NAME = 'cv';
	const DOCTRINE_PATH = './lib/Doctrine/';
}

?>