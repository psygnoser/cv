<?php

namespace CV;

require_once './db.php';
require_once './config.php';

class CV implements DB_Config
{
	function __construct()
	{
		require_once self::DOCTRINE_PATH. 'Doctrine/ORM/Tools/Setup.php';
		Doctrine\ORM\Tools\Setup::registerAutoloadDirectory( self::DOCTRINE_PATH );
	}
	
	public function render()
	{
		return 'hello';
	}
}

$cv = new CV;
print $cv->render();

?>